package dijkstra_7;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.PriorityQueue;

public class DijkstraCalculate {
	final static Integer ratLength = 3000;

	public DijkstraCalculate() {
		// TODO Auto-generated constructor stub

	}

	public void calculate(Vertex source) {
		// Algo:
		// 1. Take the unvisited node with minimum weight.
		// 2. Visit all its neighbours.
		// 3. Update the distances for all the neighbours (In the Priority
		// Queue).
		// Repeat the process till all the connected nodes are visited.

		source.minDistance = 0;
		PriorityQueue<Vertex> queue = new PriorityQueue<Vertex>();
		queue.add(source);

		while (!queue.isEmpty()) {

			Vertex u = queue.poll();
			// -----

			// System.err.println("�ļ���ȡ���1");
			// -----
			for (Edge neighbour : u.neighbours) {

				// System.err.println(tan+" tan ");

				// System.err.println(tan);
				Double newDist = u.minDistance + neighbour.weight;

				// ɾ����Ӧ�ĵ���ϵ
				// u.neighbours.remove(index);
				if (neighbour.target.minDistance > newDist) {
					// System.err.println(" mindistance  "+neighbour.target.minDistance+"  newDist"+newDist);
					// Remove the node from the queue to update the distance
					// value.
					queue.remove(neighbour.target);
					neighbour.target.minDistance = newDist;

					// Take the path visited till now and add the new node.s
					neighbour.target.path = new LinkedList<Vertex>(u.path);
					neighbour.target.path.add(u);
					// System.out.println("neighbour.target "+neighbour.target);
					// Reenter the node with new distance.
					queue.add(neighbour.target);
				}

				// System.err.println("----------------");
				// System.out.println("queue.size "+queue.size());

			}

		}
	}
}