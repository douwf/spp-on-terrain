package dijkstra_7;

import java.io.IOException;

public class GraphicAndHeight {
	// �����Ҫ������·��
		public 	GraphicAndHeight(Vertex start,String urire,String uriwr) throws IOException {
			CalculateHeight obj = new CalculateHeight();
			obj.calculate(start,urire,uriwr);
			

		}
}
