package dijkstra_7;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;

public class CalculateHeight {
	final static Integer ratLength = 3000;

	public CalculateHeight() {
		// TODO Auto-generated constructor stub

	}

	public void calculate(Vertex source, String uri_re, String uri_wr) {

		source.minDistance = 0;
		LinkedList<Vertex> queue = new LinkedList<Vertex>();
		LinkedList<String> out = new LinkedList<String>();
		queue.add(source);
		Double[][] locateNode = new Double[2][3];
		BufferedReader br = null;
		boolean flag_out = true;
		String name_out = null;
		File fwuri = new File(uri_wr);
		FileWriter fw = null;
		BufferedWriter bw = null;
		
		
		Double newDist = null;
		double xyzDouble = 1.0;
		if (fwuri.exists()) {
			boolean flag = fwuri.delete();
			if (flag) {
				try {
					fwuri.createNewFile();
					fw = new FileWriter(fwuri, true);
					bw = new BufferedWriter(fw);

					String line = null;
					Boolean flag2 = true;
					while (!queue.isEmpty()) {

						Vertex u = queue.pollFirst();
					//	System.err.println(u.name);
						Iterator<String> iter= out.iterator();
						while (iter.hasNext() && flag_out) {
							if(iter.next().equals(u.name)){
								flag_out=false;
							}
						}
						if(flag_out){
							out.addLast(u.name);// ����ɾ���Ľڵ� ��Ϊ��һ�β����ڽ������
							//System.err.println("out  "+u.name);
						}
						flag_out=true;
						
						bw.write("% " + u.name + "\r\n");
						
						// -----
						try {
							br = new BufferedReader(new FileReader(uri_re));

							while ((line = br.readLine()) != null && flag2) {

								String[] snode = line.split(" ");
								if (u.name.equals(snode[0])) {
									flag2 = false;

									locateNode[0][0] = Double.valueOf(snode[1]);
									locateNode[0][1] = Double.valueOf(snode[2]);
									if (snode[3] != null) {
										locateNode[0][2] = Double
												.valueOf(snode[3]);
									} else {
										locateNode[0][2] = 0.0;
									}

								}
							}
							
							br.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						// System.err.println("�ļ���ȡ���1");
						
// -----����-------start----------------------------------------
						for (Edge neighbour : u.neighbours) {

							try {
								br = new BufferedReader(new FileReader(uri_re));
								flag2 = true;
								while ((line = br.readLine()) != null && flag2) {
									String[] snode2 = line.split(" ");

									if (neighbour.target.name.equals(snode2[0])) {
										flag2 = false;

										locateNode[1][0] = Double
												.valueOf(snode2[1]);
										locateNode[1][1] = Double
												.valueOf(snode2[2]);
										if (snode2[3] != null) {
											locateNode[1][2] = Double
													.valueOf(snode2[3]);
										} else {
											locateNode[1][2] = 0.0;
										}

									}

								}
								br.close();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							/*
							 * �жϽǶ�
							 */
							Double lengthXY = 0.0;
							Double lengthZ = 0.0;
							lengthXY = Math.sqrt(Math.pow(
									Math.abs(locateNode[0][0] * ratLength
											- locateNode[1][0] * ratLength), 2)
									+ Math.pow(
											Math.abs(locateNode[0][1]
													* ratLength
													- locateNode[1][1]
													* ratLength), 2));
							lengthZ = (double) Math.abs(locateNode[0][2]
									- locateNode[1][2]);

							Double tan = (double) (lengthZ / lengthXY);
							 System.err.println(tan+" tan ");
							if (tan <= 1.00) {
								if (tan > 0.57735026918963) {
									xyzDouble = 3;
									// System.err.println(tan);
								}
								// System.err.println(tan);
								newDist = neighbour.weight * xyzDouble;
								neighbour.weight = newDist;
								bw.write(neighbour.target.name + " "
										+ neighbour.weight + "\r\n");
							}
							// ���ڴ洢�ڵ�
							Iterator<String>iter2= out.iterator();
							while (iter2.hasNext() && flag_out) {
								if(iter2.next().equals(neighbour.target.name)){
									flag_out=false;
								}
							}
							Iterator<Vertex> iter_queue=queue.iterator();
							while (iter_queue.hasNext() && flag_out) {
								if(iter_queue.next().name.equals(neighbour.target.name)){
									flag_out=false;
								}
							}
							if(flag_out){
								queue.addLast(neighbour.target);// ����ɾ���Ľڵ� ��Ϊ��һ�β����ڽ������
								//System.err.println("queue");
							}
							flag_out=true;

						}
//-------------��ȡ�ٽ��-----------end--------------------
						

					}

					bw.close();
					fw.close();
					br.close();

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else {
				System.err.println("���ɹ�");
				System.exit(1);
			}

		}

	}
}
