package dijkstra_7;

public class Locate {
	public  Double x;
	public  Double y;
	public  String nodeName;
	public Locate() {
		// TODO Auto-generated constructor stub
	}
	
	public Locate(String nodeName,Double x, Double y) {
		this.nodeName=nodeName;
		this.x = x;
		this.y = y;
	}
	public Locate(Double x, Double y) {
		this.x = x;
		this.y = y;
	}
	public Double getX() {
		return x;
	}

	public void setX(Double x) {
		this.x = x;
	}

	public Double getY() {
		return y;
	}

	public void setY(Double y) {
		this.y = y;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return nodeName+" "+x+" "+y;
	}
	
}
