package dijkstra_7;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class PrintRouteAndPath {
	// �����Ҫ������·��
		public 	PrintRouteAndPath(Vertex start, Vertex end,String filePath) throws IOException {
			DijkstraCalculate obj = new DijkstraCalculate();
			obj.calculate(start);
			// �ѽ�����ļ���ʽ����
			File filewriter=new File(filePath);
			FileWriter writer;
			BufferedWriter bw;
			
			// TODO Auto-generated method stub
			System.out.print("Vertex - " + end + " , Dist - " + end.minDistance
					+ " , Path - ");
			if(filewriter.exists()){
				boolean flag=filewriter.delete();
				if(flag){
					filewriter.createNewFile();
					writer = new FileWriter(filePath,true);
					bw= new BufferedWriter(writer);
					bw.write("reachable:true\r\n");
					bw.write("minStep:"+end.minDistance+"\r\n");
					bw.write("step\r\n");
					for (Vertex pathvert : end.path) {
						System.out.print(pathvert + " ");
						bw.write(pathvert+"\r\n");
					}
					System.out.println("" + end);
					
					bw.write(end+"\r\n");
					bw.close();
					writer.close();
				}else{
					System.err.println("���ɹ�");
					return;
				}
				
			}
			
			
			

		}
}
