package dijkstra_7;


import dijkstra.window.YFileChooser;


public class DijkstraTest {
	public static void main(String[] arg) {
		new YFileChooser();
		// ��ȡ�ڵ��ļ�
	}

	
}
