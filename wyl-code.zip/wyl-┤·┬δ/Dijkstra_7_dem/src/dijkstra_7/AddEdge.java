package dijkstra_7;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class AddEdge {
	public  AddEdge(String filePath, Graph g) {
		// TODO Auto-generated method stub

		BufferedReader br = null;
		String line = null;// ��¼һ�м�¼
		String node = null;
		try {
			br = new BufferedReader(new FileReader(filePath));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		try {
			while ((line = br.readLine()) != null) {
				String[] se = line.split(" ");
				if ("%".equals(se[0])) {
					node = se[1];
				} else {
					g.addEdge(node, se[0], Double.valueOf(se[1]));
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
