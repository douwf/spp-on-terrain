package dijkstra_7;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ChangedprintRouteAndPath {
	public ChangedprintRouteAndPath(Graph g, Vertex start,
			Vertex end, String nodeA, String nodeB) {
		// TODO Auto-generated method stub
		DijkstraCalculate obj = new DijkstraCalculate();
		String json = null;
		g.delEdge(nodeA, nodeB);
		g.resetMinDistance();

		obj.calculate(start);

		System.out.print("Vertex - " + end + " , Dist - " + end.minDistance
				+ " , Path - ");
		json = "reachable:true," + "minStep:" + end.minDistance + ",step:[";
		for (Vertex pathvert : end.path) {
			json += pathvert + " ";
			System.out.print(pathvert + " ");
		}
		json = json + end + "]";
		System.out.println("" + end);
		// �ѽ�����ļ���ʽ����
		FileWriter writer;
		try {
			writer = new FileWriter(
					"F://FileReader//Dijkstra_7//dijkstra_7_writer_changed.txt");
			BufferedWriter bw = new BufferedWriter(writer);
			bw.write(json);
			bw.close();
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
