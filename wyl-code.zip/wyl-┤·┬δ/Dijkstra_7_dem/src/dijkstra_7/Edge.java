package dijkstra_7;

public class Edge {
	public final Vertex target;
	public double weight;

	public Edge(Vertex target, double weight) {
		this.target = target;
		this.weight = weight;
	}
}
