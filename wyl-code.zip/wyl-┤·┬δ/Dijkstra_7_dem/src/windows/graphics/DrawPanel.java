package windows.graphics;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import javax.swing.JPanel;

import dijkstra_7.Locate;


public class DrawPanel extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String uri=null;
	Integer width=300;
	Integer height=300;
	Double x1 = 0.0,y1=0.0;
	Double x2 = 0.0,y2=0.0;
	LinkedList<Locate> loclist=new LinkedList<Locate>();
	public DrawPanel(String nodeuri) {
		// TODO Auto-generated constructor stub
		this.uri=nodeuri;
	}
	public void PanelWH(Integer width,Integer height) {
		// TODO Auto-generated constructor stub
		
		this.width=width;
		this.height=height;
	}
	public void paint(Graphics g){
		super.paint(g);
		//drawOval��������
		//1 ���Ͻǵ�X����   2 ���ϽǶ�ӦY����
		//3������Բ�Ŀ�       4������Բ�ĸ�
		//System.err.println(uri+" "+width+" "+height);//ÿ�����仯���ﶼ�ᱻ���»���
		Graphics2D g2=(Graphics2D) g;
		Line2D line2;
		Ellipse2D circle = new Ellipse2D.Double();
		BufferedReader br = null;
		String str=null;
		Double minX=null,maxX=null;
		Double minY=null,maxY=null;
		 try {
			br=new BufferedReader(new FileReader(uri));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			while((str=br.readLine())!=null){
				String[] nodeloc = str.split(" ");
				//System.err.println(Integer.parseInt(nodeloc[1])+" "+Integer.parseInt(nodeloc[2]));
				loclist.add(new Locate(Double.valueOf(nodeloc[1]), Double.valueOf(nodeloc[2])));
				if(maxX==null&&maxY==null&&minX==null&&minY==null){
					maxX=minX=Double.valueOf(nodeloc[1]);
					maxY=minY=Double.valueOf(nodeloc[2]);
					//System.err.println(maxX+minX);
				}else{
					if(Double.valueOf(nodeloc[1])<minX){
						minX=Double.valueOf(nodeloc[1]);
						//System.err.println("min "+minX);
					}
					if(Double.valueOf(nodeloc[1])>maxX){
						maxX=Double.valueOf(nodeloc[1]);
						//System.err.println("max "+maxX);
					}
					if(Integer.valueOf(nodeloc[2].substring(0,nodeloc[2].indexOf(".")))<minY){
						minY=Double.valueOf(nodeloc[2]);
					}
					if(Integer.valueOf(nodeloc[2].substring(0,nodeloc[2].indexOf(".")))>maxY){
						maxY=Double.valueOf(nodeloc[2]);
					}
				}
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Boolean flag=false;
		//System.err.println(maxX+" "+maxY+" "+minX+" "+minY);
		/*
		 * �������е� X��ֵ�Ƚ����X����Ĳ�ֵ   ��ܶ��  �������
		 * �÷���ʹ�ó���
		 * */
		
		//double BX=(maxX-minX)/(width-80);
		double BX=(width-80)/(maxX-minX);
		double BY=(height-100)/(maxY-minY);
		//System.err.println("BX "+BX+"  "+(maxX-minX)+" "+width);
		/*
		 * ��Ҫ�ı�һ���㷨
		 * */
		//System.err.println(BX);
		
		for(Locate loc:loclist){
			//circle.setFrameFromCenter((loc.getX()-minX)*BX+20, (loc.getY()-minY)*BY+20, (loc.getX()-minX)*BX+20+2, (loc.getY()-minY)*BY+20+2);
			//g2.drawOval((loc.getX()-minX)/BX+20, (loc.getY()-minY)*BY+20, 2, 2);
			//g2.draw(circle);
			//System.err.println(loc.getX()+" "+loc.getY());
			if(flag==false){
				
				x2=Double.valueOf(loc.getX());
				y2=Double.valueOf(loc.getY());
				flag=true;
			}else{
				x1=x2;
				y1=y2;
				x2=Double.valueOf(loc.getX());
				y2=Double.valueOf(loc.getY());
				line2=new Line2D.Double((x1-minX)*BX+20, (y1-minY)*BY+20,(x2-minX)*BX+20, (y2-minY)*BY+20);
				g2.draw(line2);
				
			}
			
			
		}
		loclist=new LinkedList<Locate>();//���һ�´�������
		
	}
	
	
	
	
}
