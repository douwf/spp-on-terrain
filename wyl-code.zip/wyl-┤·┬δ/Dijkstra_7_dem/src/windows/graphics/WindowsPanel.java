package windows.graphics;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class WindowsPanel extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	DrawPanel mp = null;
	JButton button_back=new JButton("����������");
	final JFrame drframe=new JFrame("����·������");
	
	public WindowsPanel(String uri) {
		// TODO Auto-generated constructor stub
		mp = new DrawPanel(uri);
		ComponentListener lister = new ComponentListener() {

			@Override
			public void componentShown(ComponentEvent e) {
				// TODO Auto-generated method stub
				//System.err.println("componentShown");
			}

			@Override
			public void componentResized(ComponentEvent e) {
				// TODO Auto-generated method stub
				//System.err.println("componentResized");
				Component comp = (Component) e.getSource();
				//System.err.println(comp.getSize().width + "  "
					//	+ comp.getSize().height);
				mp.PanelWH(comp.getSize().width, comp.getSize().height);
			}

			@Override
			public void componentMoved(ComponentEvent e) {
				// TODO Auto-generated method stub
				//System.err.println("componentMoved");
			}

			@Override
			public void componentHidden(ComponentEvent e) {
				// TODO Auto-generated method stub
				//System.err.println("componentHidden");
			}
		};
		
		drframe.setLayout(new BorderLayout());
		drframe.add(mp,BorderLayout.CENTER);
		drframe.add(button_back,BorderLayout.SOUTH);
		button_back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				drframe.dispose();//�رջ���ͼ����
			}
		});
		Dimension scrSize = Toolkit.getDefaultToolkit().getScreenSize();
		
		drframe.setSize(400, 300);
		// mp.PanelWH(this.getWidth(), this.getHeight());
		drframe.setLocation((scrSize.width - this.getWidth()) / 2,
				(scrSize.height - this.getHeight()) / 2);
		
		drframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		drframe.setVisible(true);
		drframe.addComponentListener(lister);
	}

	/*public static void main(String[] args) {
		new WindowsPanel("F://FileReader//Dijkstra_7//1010//writernode_RJQ_short.txt");
	}*/
}
