package domain16_tpyramid;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class domain16_tpyramid_10000 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int minX = 0;
		final int maxX = 809;
		int minY = 0;
		final int maxY = 809;
		long count1=0;
		long count2=0;
		final long MAXLONG=1000000000000000l;
		
		long startTime=System.currentTimeMillis(); //��ȡ����ʱ��
		File fw = new File("G:/wyl_weightTra/weight16/weight16_001h_30.txt");
		
		FileWriter writer;
		BufferedWriter bw;
		double Xdept = 10.0;
		double Ydept = 10.0;
		double weight=1.0,weight_sqrt=Math.sqrt(Xdept*Xdept+Ydept*Ydept);
		double weight_sqrtx=Math.sqrt((Xdept+Xdept)*(Xdept+Xdept)+Ydept*Ydept);
		double weight_sqrty=Math.sqrt(Xdept*Xdept+(Ydept+Ydept)*(Ydept+Ydept));
		double Height=0.0;
		
		if (fw.exists()) {
			boolean flag = fw.delete();
			if (flag) {
				fw.createNewFile();
				System.err.println("success");
			} else {
				System.err.println("fail");
			}
		}
		writer = new FileWriter(fw);
		bw = new BufferedWriter(writer);
		// œøÐÐÐŽÈëÊýŸÝ
		String[][] dataName = new String[maxY+1][maxX+1];
		double[][] height=new double[maxY+1][maxX+1];
		int ry=0;
		int rx=0;
		for(ry=0;ry<maxY+1;ry++){
			for(rx=0;rx<maxX+1;rx++){
				
				if(ry<10&&rx<10){
					dataName[ry][rx]="v"+"000"+ry+"000"+rx;
				}else if(ry<10&&rx>=10&&rx<100){
					dataName[ry][rx]="v"+"000"+ry+"00"+rx;
				}else if(ry<10&&rx>=100&&rx<1000){
					dataName[ry][rx]="v"+"000"+ry+"0"+rx;
				}else if(ry<10&&rx>=1000&&rx<10000){
					dataName[ry][rx]="v"+"000"+ry+rx;
				}else if(ry>=10&&ry<100&&rx<10){
					dataName[ry][rx]="v"+"00"+ry+"000";
				}else if(ry>=10&&ry<100&&rx>=10&&rx<100){
					dataName[ry][rx]="v"+"00"+ry+"00"+rx;
				}else if(ry>=10&&ry<100&&rx>=100&&rx<1000){
					dataName[ry][rx]="v"+"00"+ry+"0"+rx;
				}else if(ry>=10&&ry<100&&rx>=1000&&rx<10000){
					dataName[ry][rx]="v"+"00"+ry+rx;
				}else if(ry>=100&&ry<1000&&rx<10){
					dataName[ry][rx]="v"+"0"+ry+"000"+rx;
				}else if(ry>=100&&ry<1000&&rx>=10&&rx<100){
					dataName[ry][rx]="v"+"0"+ry+"00"+rx;
				}else if(ry>=100&&ry<1000&&rx>=100&&rx<1000){
					dataName[ry][rx]="v"+"0"+ry+"0"+rx;
				}else if(ry>=100&&ry<1000&&rx>=1000&&rx<10000){
					dataName[ry][rx]="v"+"0"+ry+rx;
				}else if(ry>=1000&&rx<10){
					dataName[ry][rx]="v"+ry+"000"+rx;
				}else if(ry>=1000&&rx>=10&&rx<100){
					dataName[ry][rx]="v"+ry+"00"+rx;
				}else if(ry>=1000&&rx>=100&&rx<1000){
					dataName[ry][rx]="v"+ry+"0"+rx;
				}else {
					dataName[ry][rx]="v"+ry+rx;
				}
			}
		}

		//°Ñžß³ÌÖµ¶ÁÈëÄÚŽæÖÐ£¬±£ŽæÔÚÊý×éÖÐ
		File fr = new File("G:/001h_height/height001h_30.txt");
		FileReader reader = null;
		BufferedReader br = null;
		String[] sh=null;
		//°ŽÐÐ¶ÁÈë
		if(fr.exists()){
			reader=new FileReader(fr);
			br=new BufferedReader(reader);
			for (ry = 0; ry < maxY+1; ry++) {
				String line=br.readLine();
				sh = line.split(",");
				for (rx = 0; rx < maxX+1; rx++) {
					height[ry][rx]=Double.valueOf(sh[rx]);
					//System.err.print(height[ry][rx]+" ");
				}
				
			}
			
		}
		//System.err.println(height[100][100]);
		// ÐŽÈëµœÎÄŒþÖÐ
		// ÈšÖØÖµÎª   ÁœµãŒäµÄŸàÀë
		
		for (ry = 0; ry < maxY+1; ry++) {
			for (rx = 0; rx <maxX+1; rx++) {
				// 4 ge dingjiao
				if ( ry == minY&&rx == minX) {
					
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ²Ù×÷
					if(height[ry][rx]!=0){
						if(height[ry][rx + 1]!=0){
							Height=Math.abs (height[ry][rx]-height[ry][rx + 1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
					
				} else if (ry == minY && rx == maxX) {
					
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ²Ù×÷
					if(height[ry][rx]!=0){
						if(height[ry+1][rx]!=0){
							Height=Math.abs (height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						
						//
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					

				} else if (ry == maxY && rx == minX) {
					
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ²Ù×÷
					if(height[ry][rx]!=0){
						if(height[ry-1][rx]!=0){
							Height=Math.abs (height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry - 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
					}
					

				} else if (ry == maxY && rx == maxX) {
					
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ²Ù×÷
					if(height[ry][rx]!=0){
						if(height[ry-1][rx]!=0){
							Height=Math.abs (height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry - 1][rx]+ " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						//
						if(height[ry-2][rx-1]!=0){
							
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				
				}//8 ge xiedingjiao 
				else if (ry == minY&&rx==minX+1) {
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if(ry == minY&&rx==maxX-1){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if(ry == maxY&&rx==minX+1) {
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if(ry == maxY&&rx==maxX-1){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if(ry==minY+1&&rx==minX){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
				
				}else if(ry==maxY-1&&rx==minX){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//1
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;	
						}
						//3
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if(ry==minY+1&&rx==maxX){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if(ry==maxY-1&&rx==maxX){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							
						}
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				} 
				//4 ge duijiaodingdian
				else if(ry==minY+1&&rx==minX+1){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
					
				}else if(ry==minY+1&&rx==maxX-1){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;	
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if(ry==maxY-1&&rx==minX+1){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if(ry==maxY-1&&rx==maxX-1){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							
						}
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}
				//4 ge dingbian
				else if (ry == minY) {
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}	
					}
					
				}else if(ry==maxY){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						//
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;	
						}
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
					}
				
				}else if (rx == minX) {
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//
						//1
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if (rx == maxX) {
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						//
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				} 
				//4 ge gebiandingdiao
				else if (ry == minY+1) {
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						//
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if(ry==maxY-1){
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						//
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if (rx == minX+1) {
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						//
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}else if (rx == maxX-1) {
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
					
				} 
				else {
					
					bw.write("% " + dataName[ry][rx]+"\r\n");
					//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
					if(height[ry][rx]!=0){
						if(height[ry-1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							
						}
						if(height[ry][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//
						//1
						if(height[ry-2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry - 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
						//2
						if(height[ry-1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry-1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry - 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//3
						if(height[ry+1][rx-2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx - 2] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+1][rx+2]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+2]);
							weight=Math.sqrt(Height*Height+weight_sqrtx*weight_sqrtx);
							bw.write(dataName[ry + 1][rx + 2] + " " + weight+"\r\n");
							count1++;
						}
						//4
						if(height[ry+2][rx-1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx - 1] + " " + weight+"\r\n");
							count1++;
						}
						if(height[ry+2][rx+1]!=0){
							Height=Math.abs(height[ry][rx]-height[ry+2][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrty*weight_sqrty);
							bw.write(dataName[ry + 2][rx + 1] + " " + weight+"\r\n");
							count1++;
						}
					}
					
				}

			}
			
			if(count1>=MAXLONG){
				count2=count1/MAXLONG;
				count1=count1%MAXLONG;
			}
			
		}
		bw.close();
		writer.close();
		System.out.println(count2+" "+count1);
		long endTime=System.currentTimeMillis(); //��ȡ����ʱ��
		System.out.println("·�����ɳ�������ʱ�䣺 "+(endTime-startTime)+"ms");
	}

}
