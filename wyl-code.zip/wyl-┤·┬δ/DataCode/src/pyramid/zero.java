package pyramid;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class zero {

	public static void main(String[] args) throws IOException {
		final int Xmax=90,Ymax=90;//µÍ·Ö±æÂÊ
		final int XmaxH=270,YmaxH=270;//žß·Ö±æÂÊ
		final int fenBianL=3;
		final int pointNum=8;
		int [][]point=new int[Xmax][Ymax];
		long startTime=System.currentTimeMillis(); //��ȡ����ʱ��
		//Â·Ÿ¶µã
		int []route= {0,0,
				0,1,
				0,2,
				1,2,
				2,2,
				3,2,
				4,2,
				5,2,
				5,3,
				5,4,
				5,5,
				6,5,
				6,6,
				7,6,
				7,7,
				8,7,
				8,8,
				9,8,
				9,9,
				10,9,
				10,10,
				10,11,
				10,12,
				10,13,
				10,14,
				10,15,
				10,16,
				10,17,
				10,18,
				10,19,
				11,19,
				11,20,
				11,21,
				11,22,
				12,22,
				12,23,
				13,23,
				13,24,
				13,25,
				13,26,
				13,27,
				13,28,
				13,29,
				13,30,
				13,31,
				14,31,
				14,32,
				15,32,
				16,32,
				17,32,
				18,32,
				19,32,
				19,33,
				20,33,
				21,33,
				21,34,
				22,34,
				23,34,
				23,35,
				24,35,
				25,35,
				26,35,
				27,35,
				28,35,
				29,35,
				30,35,
				30,36,
				31,36,
				32,36,
				33,36,
				34,36,
				35,36,
				36,36,
				37,36,
				38,36,
				39,36,
				40,36,
				40,37,
				40,38,
				41,38,
				41,39,
				41,40,
				41,41,
				41,42,
				42,42,
				43,42,
				43,43,
				44,43,
				45,43,
				46,43,
				47,43,
				48,43,
				48,44,
				48,45,
				49,45,
				50,45,
				51,45,
				51,46,
				51,47,
				51,48,
				52,48,
				53,48,
				53,49,
				53,50,
				54,50,
				54,51,
				54,52,
				54,53,
				54,54,
				55,54,
				56,54,
				57,54,
				58,54,
				58,55,
				58,56,
				58,57,
				58,58,
				58,59,
				58,60,
				59,60,
				59,61,
				59,62,
				59,63,
				60,63,
				60,64,
				61,64,
				62,64,
				63,64,
				63,65,
				64,65,
				65,65,
				65,66,
				65,67,
				65,68,
				66,68,
				67,68,
				67,69,
				68,69,
				68,70,
				68,71,
				69,71,
				70,71,
				71,71,
				72,71,
				73,71,
				74,71,
				75,71,
				75,72,
				76,72,
				77,72,
				77,73,
				78,73,
				79,73,
				79,74,
				80,74,
				80,75,
				81,75,
				82,75,
				82,76,
				83,76,
				83,77,
				84,77,
				85,77,
				85,78,
				85,79,
				85,80,
				85,81,
				85,82,
				85,83,
				86,83,
				87,83,
				87,84,
				87,85,
				87,86,
				87,87,
				88,87,
				88,88,
				88,89,
				89,89,};
		//³õÊŒ»¯
		for(int i=0;i<Xmax;i++){
			for(int j=0;j<Xmax;j++) {
				point[i][j]=0;
			}
		}
		
		int number=route.length;
		System.out.println(number+" "+route[number-1]);
		//xÖá   Á¬×ÔÉí ÓëÏàÁ¬µÄ3žöž÷Íøµã
		for(int i=0;i<number/2;i++) {
			int num=route[i*2+1];
			for(int j=num;j<num+pointNum&&j<Xmax;j++) {
				point[route[i*2]][j]=1;
			}
			
		}
		//yÖá
		for(int i=0;i<number/2;i++) {
			int num=route[i*2];
			for(int j=num;j<num+pointNum&&j<Xmax;j++) {
				point[j][route[i*2+1]]=1;
			}
		}
		
		//œøÐÐÀ©Õ¹µã  30*30·Ö±æÂÊl--90*90·Ö±æÂÊm ×ª»¯
		int [][] pointMid=new int [XmaxH][YmaxH];
		//³õÊŒ»¯
		for(int i=0;i<XmaxH;i++){
			for(int j=0;j<XmaxH;j++) {
				pointMid[i][j]=0;
			}
		}
		for(int i=0;i<Xmax;i++) {
			for(int j=0;j<Xmax;j++) {
				if(point[i][j]==1) {
					for(int x=i*fenBianL;x<i*fenBianL+fenBianL;x++) {
						for(int y=j*fenBianL;y<j*fenBianL+fenBianL;y++) {
							pointMid[x][y]=1;
						}
					}
					
				}
			}
		}
		
		
		/**
		 * 1¡¢¶ÁÈ¡ÊýŸÝ žß³ÌÖµÊýŸÝ
		 * 2¡¢žÄÐŽžß³ÌÖµÊýŸÝ
		 * 3¡¢ÐŽÈëµœ¶ÔÓŠµÄÎÄŒþÖÐ
		 * */
		//ÐŽÎÄŒþ ¶ÔÓŠµÄÎÄŒþÃû
		File fw = new File("/tmp/guest-hzimnl/Desktop/Data90_810/4_003m_height270_8.txt");
		FileWriter writer;
		BufferedWriter bw;
		//ÅÐ¶ÏÎÄŒþÊÇ·ñŽæÔÚ
		if (fw.exists()) {
			boolean flag = fw.delete();
			if (flag) {
				fw.createNewFile();
				System.err.println("success");
			} else {
				System.err.println("fail");
			}
		}
		writer = new FileWriter(fw);
		bw = new BufferedWriter(writer);
		//°Ñžß³ÌÖµ¶ÁÈëÄÚŽæÖÐ£¬±£ŽæÔÚÊý×éÖÐ
		File fr = new File("/tmp/guest-hzimnl/Desktop/Data90_810/writerGDAL_58_06_003m_height270.txt");
		FileReader reader = null;
		BufferedReader br = null;
		int ry=0,rx=0;
		
		//°ŽÐÐ¶ÁÈë  žß·Ö±æµÄžß³ÌÖµÊýŸÝ
		if(fr.exists()){
			reader=new FileReader(fr);
			br=new BufferedReader(reader);
			for (ry = 0; ry < XmaxH; ry++) {
				String[] sh = br.readLine().split(",");
				for (rx = 0; rx < XmaxH; rx++) {
					
					if(pointMid[ry][rx]==0) {
						sh[rx]="0";
					}
					
				}
				//ÐŽÈëµœÎÄŒþÖÐ
				for(int k=0;k<XmaxH-1;k++){
					//System.out.print(sh[k]+",");
					bw.write(sh[k]+",");
				}
				//System.out.println(sh[XmaxH-1]);	
				bw.write(sh[XmaxH-1]+"\r\n");
				//System.out.println(ry);
			}
			//System.out.println(ry);		
		}
		bw.close();
		br.close();
		long endTime=System.currentTimeMillis(); //��ȡ����ʱ��
		System.out.println("time sum: "+(endTime-startTime)+"ms");
	
	}

}
