package nodeName;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class nodeName100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ry=0;
		int rx=0;
		
		final int xnum=30;
		final int ynum=30;
		//œøÐÐÎÄŒþµÄÐŽÈë
		File fw = new File("/tmp/guest-vpbcfz/Desktop/nodeName/nodeName_001l_30.txt");
		FileWriter writer;
		BufferedWriter bw;
		if (fw.exists()) {
			boolean flag = fw.delete();
			if (flag) {
				try {
					fw.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.err.println("success");
			} else {
				System.err.println("fail");
			}
		}
		try {
			writer = new FileWriter(fw);
			bw = new BufferedWriter(writer);
			for(ry=0;ry<ynum;ry++){
				for(rx=0;rx<xnum;rx++){
					
					if(ry<10&&rx<10){
						bw.write("v"+"0"+ry+"0"+rx+"\r\n");
					}else if(ry<10&&rx>=10){
						bw.write("v"+"0"+ry+rx+"\r\n");
					}else if(ry>=10&&rx<10){
						bw.write("v"+ry+"0"+rx+"\r\n");
					}else{
						bw.write("v"+ry+rx+"\r\n");
					}
				}
			}
			bw.close();
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
