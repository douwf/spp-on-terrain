package domain8_tpyramid;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class domain8_100 {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				int minX = 0;
				final int maxX = 29;
				int minY = 0;
				final int maxY = 29;
				long count1=0;
				long count2=0;
				final long MAXLONG=1000000000000000l;
				
				long startTime=System.currentTimeMillis(); //��ȡ����ʱ��
				File fw = new File("/tmp/guest-bl5kuk/Desktop/weight8/weight8_009l_30.txt");
				FileWriter writer;
				BufferedWriter bw;
				double Xdept = 90.0;
				double Ydept = 90.0;
				double weight=1.0,weight_sqrt=Math.sqrt(Xdept*Xdept+Ydept*Ydept);
				double Height=0.0;
				if (fw.exists()) {
					boolean flag = fw.delete();
					if (flag) {
						fw.createNewFile();
						System.err.println("success");
					} else {
						System.err.println("fail");
					}
				}
				writer = new FileWriter(fw);
				bw = new BufferedWriter(writer);
				// œøÐÐÐŽÈëÊýŸÝ
				String[][] dataName = new String[maxY+1][maxX+1];
				double[][] height=new double[maxY+1][maxX+1];
				int ry=0;
				int rx=0;
				for(ry=0;ry<maxY+1;ry++){
					for(rx=0;rx<maxX+1;rx++){
						
						if(ry<10&&rx<10){
							dataName[ry][rx]="v"+"0"+ry+"0"+rx;
						}else if(ry<10&&rx>=10&&rx<100){
							dataName[ry][rx]="v"+"0"+ry+rx;
						}else if(ry>=10&&rx<10){
							dataName[ry][rx]="v"+ry+"0"+rx;
						}else{
							dataName[ry][rx]="v"+ry+rx;
						}
					}
				}

				//°Ñžß³ÌÖµ¶ÁÈëÄÚŽæÖÐ£¬±£ŽæÔÚÊý×éÖÐ
				File fr = new File("/tmp/guest-bl5kuk/Desktop/data_pyramid/writerGDAL_58_06_009l_height30.txt");
				FileReader reader = null;
				BufferedReader br = null;
				String[] sh=null;
				//°ŽÐÐ¶ÁÈë
				if(fr.exists()){
					reader=new FileReader(fr);
					br=new BufferedReader(reader);
					for (ry = 0; ry < maxY+1; ry++) {
						String line=br.readLine();
						sh = line.split(",");
						for (rx = 0; rx < maxX+1; rx++) {
							height[ry][rx]=Double.valueOf(sh[rx]);
							//System.err.print(height[ry][rx]+" ");
						}
						
					}
					
				}
				//System.err.println(height[100][100]);
				// ÐŽÈëµœÎÄŒþÖÐ
				// ÈšÖØÖµÎª   ÁœµãŒäµÄŸàÀë
				
				for (ry = 0; ry < maxY+1; ry++) {
					for (rx = 0; rx <maxX+1; rx++) {
						// ËÄžöœÇÌØÊâ»¯
						if ( ry == minY&&rx == minX) {
							
							bw.write("% " + dataName[ry][rx]+"\r\n");
							//ÎŽœøÐÐŒôÖŠ²Ù×÷
							Height=Math.abs (height[ry][rx]-height[ry][rx + 1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1+=3;
							
						} else if (ry == minY && rx == maxX) {
							
							bw.write("% " + dataName[ry][rx]+"\r\n");
							//ÎŽœøÐÐŒôÖŠ²Ù×÷
							Height=Math.abs (height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx - 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1+=3;

						} else if (ry == maxY && rx == minX) {
							
							bw.write("% " + dataName[ry][rx]+"\r\n");
							//ÎŽœøÐÐŒôÖŠ²Ù×÷
							Height=Math.abs (height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry - 1][rx] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							count1+=3;

						} else if (ry == maxY && rx == maxX) {
							
							bw.write("% " + dataName[ry][rx]+"\r\n");
							//ÎŽœøÐÐŒôÖŠ²Ù×÷
							Height=Math.abs (height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry - 1][rx]+ " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx - 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							count1+=3;
						

						} else if (ry == minY) {
							
							bw.write("% " + dataName[ry][rx]+"\r\n");
							//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx - 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1+=5;
							
						} else if (ry == maxY) {
							
							bw.write("% " + dataName[ry][rx]+"\r\n");
							//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx - 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry - 1][rx] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							count1+=5;

						} else if (rx == minX) {
							
							bw.write("% " + dataName[ry][rx]+"\r\n");
							
							//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry - 1][rx] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1+=5;
							

						} else if (rx == maxX) {
							
							bw.write("% " + dataName[ry][rx]+"\r\n");
							//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry - 1][rx] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx - 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							count1+=5;
							

						} else {
							
							bw.write("% " + dataName[ry][rx]+"\r\n");
							//ÎŽœøÐÐŒôÖŠ³Ž×÷ 
							Height=Math.abs(height[ry][rx]-height[ry-1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx - 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry-1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry-1][rx] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry-1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry - 1][rx + 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry][rx-1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx-1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry][rx+1]);
							weight=Math.sqrt(Height*Height+Xdept*Xdept);
							bw.write(dataName[ry][rx + 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx-1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx - 1] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx]);
							weight=Math.sqrt(Height*Height+Ydept*Ydept);
							bw.write(dataName[ry + 1][rx] + " " + weight+"\r\n");
							
							Height=Math.abs(height[ry][rx]-height[ry+1][rx+1]);
							weight=Math.sqrt(Height*Height+weight_sqrt*weight_sqrt);
							bw.write(dataName[ry + 1][rx + 1] + " " + weight+"\r\n");
							count1+=8;
							
						}

					}
					if(count1>=MAXLONG){
						count2=count1/MAXLONG;
						count1=count1%MAXLONG;
					}
					
				}
				bw.close();
				writer.close();
				System.out.println(count2+" "+count1);
				long endTime=System.currentTimeMillis(); //��ȡ����ʱ��
				System.out.println("·�����ɳ�������ʱ�䣺 "+(endTime-startTime)+"ms");
	}

}
