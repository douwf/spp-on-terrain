package interceptData;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class interceptData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader br=null;
		
		FileWriter fw=null;
		BufferedWriter bw;
		try {
			br=new BufferedReader(new FileReader("C://Users//wyw//Desktop//wyl//data_delete//writerGDAL_58_06_003m_height.txt"));
			fw=new FileWriter("C://Users//wyw//Desktop//wyl//data_delete//writerGDAL_58_06_003m_height90.txt");
			bw=new BufferedWriter(fw);
			
			for(int j=0;j<90;j++){
				String[] sh=br.readLine().split(",");
				//String line=br.readLine();
				
				for(int k=0;k<89;k++){
						//System.out.print(sh[k]+",");
					bw.write(sh[k]+",");
				}
				bw.write(sh[89]+"\r\n");
				
				
				//System.out.println(sh[269]);
				
			}
			
			br.close();
			bw.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
