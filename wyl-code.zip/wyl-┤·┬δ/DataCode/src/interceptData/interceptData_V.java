package interceptData;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class interceptData_V {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		final int LENGTH=1000;
		//write file
		File fw=new File("/tmp/guest-hzimnl/Desktop/route4/route4_003m_270_8_org.txt");
		FileWriter writer;
		BufferedWriter bw;
		if (fw.exists()) {
			boolean flag = fw.delete();
			if (flag) {
				fw.createNewFile();
				System.err.println("success");
			} else {
				System.err.println("fail");
			}
		}
		writer = new FileWriter(fw);
		bw = new BufferedWriter(writer);
		//read file
		File fr=new File("/tmp/guest-hzimnl/Desktop/route4/route4_003m_270_8.txt");
		FileReader reader = null;
		BufferedReader br = null;
		String[] sh=null;
		if(fr.exists()){
			reader=new FileReader(fr);
			br=new BufferedReader(reader);
			//qudiao qian sange
			br.readLine();
			br.readLine();
			br.readLine();
			String line=null;
			while((line=br.readLine())!=null){
				
				sh=line.split("v");
				int lineNum=0;
				lineNum=Integer.parseInt(sh[1]);
				//System.out.println(lineNum/100+" - "+lineNum%100);
				bw.write(lineNum/LENGTH+","+lineNum%LENGTH+","+"\r\n");
			}
			
			
		}
		bw.close();
		br.close();
		
			
		
	}

}
