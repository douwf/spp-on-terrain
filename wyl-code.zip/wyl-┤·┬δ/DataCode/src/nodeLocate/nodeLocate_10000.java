package nodeLocate;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class nodeLocate_10000 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		double Xdept = 10;
		double Ydept = 10;
		final int Xnum=2430;
		final int Ynum=2430;
		// œøÐÐÎÄŒþµÄ¶ÁÈ¡
		File fr = new File("C:\\Users\\wyw\\Desktop\\wyl\\data_delete\\writerGDAL_58_06_001h_height270.txt");
		FileReader reader = null;
		BufferedReader br = null;
		// œøÐÐÎÄŒþµÄÐŽÈë
		File fw = new File("C:\\Users\\wyw\\Desktop\\wyl\\data_delete\\writerGDAL_58_06_001h_Nodelocate270.txt");
		FileWriter writer;
		BufferedWriter bw;
		if (fw.exists()) {
			boolean flag = fw.delete();
			if (flag) {
				try {
					fw.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.err.println("ŽŽœšÐÂÎÄŒþ");
			} else {
				System.err.println("ÉŸ³ýÊ§°Ü");
			}
		}

		int ry = 0;
		int rx = 0;
		String line = null;
		if (fr.exists()) {
			reader=new FileReader(fr);
			br=new BufferedReader(reader);
			writer = new FileWriter(fw);
			bw = new BufferedWriter(writer);
			for (ry = 0; ry < Ynum; ry++) {
				
				String[] sh = br.readLine().split(",");
				for (rx = 0; rx < Xnum; rx++) {
					if(ry<10&&rx<10){
						bw.write("v"+"000"+ry+"000"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry<10&&rx>=10&&rx<100){
						bw.write("v"+"000"+ry+"00"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry<10&&rx>=100&&rx<1000){
						bw.write("v"+"000"+ry+"0"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry<10&&rx>=1000&&rx<10000){
						bw.write("v"+"000"+ry+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=10&&ry<100&&rx<10){
						bw.write("v"+"00"+ry+"000"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=10&&ry<100&&rx>=10&&rx<100){
						bw.write("v"+"00"+ry+"00"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=10&&ry<100&&rx>=100&&rx<1000){
						bw.write("v"+"00"+ry+"0"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=10&&ry<100&&rx>=1000&&rx<10000){
						bw.write("v"+"00"+ry+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=100&&ry<1000&&rx<10){
						bw.write("v"+"0"+ry+"000"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=100&&ry<1000&&rx>=10&&rx<100){
						bw.write("v"+"0"+ry+"00"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=100&&ry<1000&&rx>=100&&rx<1000){
						bw.write("v"+"0"+ry+"0"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=100&&ry<1000&&rx>=1000&&rx<10000){
						bw.write("v"+"0"+ry+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=1000&&rx<10){
						bw.write("v"+ry+"000"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=1000&&rx>=10&&rx<100){
						bw.write("v"+ry+"00"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else if(ry>=1000&&rx>=100&&rx<1000){
						bw.write("v"+ry+"0"+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}else {
						bw.write("v"+ry+rx+" "+ry*Ydept+" "+rx*Xdept+" "+sh[rx]+"\r\n");
					}
					
				}
				
			}
			bw.close();
			writer.close();
			br.close();
			reader.close();
		} else {
			System.exit(1);
		}
	}

}
