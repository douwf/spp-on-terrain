package com.astar;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
public class TestPoint {
	
	 	
		
		public static final int NUM_X=123;
	    public static final int NUM_Y=149;
	    public static int number=0;
		public static String[] str=new String[4000];
	    /*����洢�߳�ֵ������*/
	    public static double[][] height=new double[NUM_X][NUM_Y];
		@Test
	    public void test2() {
			 
		    //��ȡ�߳�ֵ
		    File fr = new File("F://FileReader//a_data//123_149//height.txt");
			FileReader reader = null;
			BufferedReader br = null;
			//���ж���
			if(fr.exists()){
				try {
					reader=new FileReader(fr);
					br=new BufferedReader(reader);
					
					for (int ry = 0; ry < NUM_X; ry++) {
						String[] sh = br.readLine().split(",");
						for (int rx = 0; rx < NUM_Y; rx++) {
							height[ry][rx]=Double.valueOf(sh[rx]);
									
						}
					}
						
				
				} catch ( IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	        AStar aStar = new AStar();  
	        Set<Point> barrier = new HashSet<Point>();  
	        
	        long start = System.currentTimeMillis();  
	        
	            aStar = new AStar();  
	            aStar.move(0, 0, 122, 122, barrier); //�����ʾ��ʼ�����յ� 
	            /*��㣺10, 25 ��25�е�10�У���0�е�0�У�
	             *�յ㣺28, 40��40�е�28�У���0�е�0�У�
	             * */
	        
	          
	        Set<Point> set = new HashSet<Point>();  
	        Point endPoint = aStar.getEndPoint();  
	        Point startPoint = aStar.getStartPoint();  
	        Map<String, Point> openMap = aStar.getOpenMap();  
	        Map<String, Point> closeMap = aStar.getCloseMap(); 
	        str[number++]=aStar.getEndPoint().getKey();
	        set = TestPoint.get(endPoint, set); 
	        //д��·��
	        File fw = new File("f://FileReader//a_data//123_149//route.txt");
			FileWriter writer;
			BufferedWriter bw;
			
			
			if (fw.exists()) {
				boolean flag = fw.delete();
				if (flag) {
					try {
						fw.createNewFile();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.err.println("�������ļ�");
				} else {
					System.err.println("ɾ��ʧ��");
				}
			}
			try {
				writer = new FileWriter(fw);
				bw = new BufferedWriter(writer);
				for(int i=0;i<number;i++){
					bw.write(str[i]+"\r\n");
				}
				bw.close();
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	        number=0;
	        str=null;
	        long end = System.currentTimeMillis();  
	        System.out.println("�㷨ʱ��"+(end - start));
	 	}
	      
	  
	    public static Set<Point> get(Point p, Set<Point> set) {  
	    	//�����ļ���д��
	    	
	        if (p != null) {  
	            set.add(p);  
	        }  
	        Point pp = p.prev; 
	        
	        if (pp != null) { 
	        	System.err.println(pp.x+" "+pp.y);
	        	str[number++]=pp.x+" "+pp.y;
	            TestPoint.get(pp, set);  
	        } else {  
	            return set;  
	        }  
	        return set;  
	    }  
	   
}
