package aco;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;
/*
 * ���ڴ�
 * ʹ�þ��������е�֮��ľ����ϵ
 * N*N
 * */
/**
 * 
 * @author BIAO YU
 * 
 *
 */
public class ACO {
	private List<Ant> ants; // ����
	private int antNum; // ��������
	private int MAX_GEN; // ���д���
	private float[][] pheromone; //��Ϣ�ؾ���

	public static int bestLength; // ��ѳ���
	public static List<Integer> bestTour; // ���·��
	public static int firstCity;// ��ʼ����
	public static int lastCity;// ��������
	public static Vector<City> cities;// ���г�������
	public static int cityNum;// ��������
	public static HashMap<Integer, Vector<Integer>> cityPath = new HashMap<Integer, Vector<Integer>>();// ������нڵ����������ڽڵ�

	// ��Ϣ����������
	public static float alpha;
	public static float beta;
	public static float rho;

	public ACO(int m, int g, float a, float b, float r, int f, int l) {
		antNum = m;
		ants = new ArrayList<Ant>(antNum);
		MAX_GEN = g;
		alpha = a;
		beta = b;
		rho = r;
		firstCity = f;
		lastCity = l;
	}

	/**
	 * ��ʼ��ACO�㷨��
	 * 
	 * @param posFile
	 * @param pathFile
	 * @throws IOException
	 */

	public void init(String posFile, String pathFile) throws IOException {
		// ��ȡ��������
		String strbuff;
		//��
		BufferedReader posBR = new BufferedReader(new InputStreamReader(new FileInputStream(posFile)));
		//·��
		BufferedReader pathBR = new BufferedReader(new InputStreamReader(new FileInputStream(pathFile)));
		cities = new Vector<City>();
		//�洢��Ӧ�ĳ���
		while ((strbuff = posBR.readLine()) != null) {
			String[] strcol = strbuff.split(" ");
			// ¼���������    ��ά����
			int x = Integer.valueOf(strcol[1]);
			int y = Integer.valueOf(strcol[2]);
			int z = Integer.valueOf(strcol[3]);
			City city = new City(x, y, z);
			cities.add(city);
		}
		cityNum = cities.size();
		posBR.close();

		// ��ȡ�ڱ߹�ϵ����
		String lineTxt = null;
		List<SingleDelta> initDelta = new ArrayList<>();
		while ((lineTxt = pathBR.readLine()) != null) {
			String[] txts = lineTxt.split(" ");
			
			SingleDelta singleDelta = new SingleDelta(Integer.parseInt(txts[0]), Integer.parseInt(txts[1]), 0.f);
			initDelta.add(singleDelta);

		}
		pathBR.close();

	
		// ��ʼ����Ϣ�ؾ���
		pheromone = new float[cityNum][cityNum];
		for (int i = 0; i < cityNum; i++) {
			for (int j = 0; j < cityNum; j++) {
				pheromone[i][j] = 0.1f; // ��ʼ��Ϊ0.1
			}
		}
		bestLength = Integer.MAX_VALUE;
		bestTour = new ArrayList<Integer>();
		bestTour.add(firstCity);

		// ��ʼ������	
		for (int i = 0; i < antNum; i++) {
			ants.add(new Ant(initDelta));
			ants.get(i).init();
		}
		
	}

	/**
	 * ��ѭ��
	 */
	public void solve(String fileOutUrl) {
		for (int g = 0; g < MAX_GEN; g++) {
			for (int i = 0; i < ants.size(); i++) {
				System.out.println("====ant:" + i + " start====");
				System.out.println("firstCity:" + firstCity);
				for (int j = 1; j < cityNum; j++) {
					// ��ǰ�����Ѿ��ߵ����յ�
					if (ants.get(i).getTabu().contains(lastCity)) {
						System.out.println("ant:" + i + " tabu" + ants.get(i).getTabu());
						System.out.println("ant:" + i + " TourLength " + ants.get(i).getTourLength());
						System.out.println("====ant:" + i + " end====");
						break;
					} else {
						// ��ǰ����û��·��������
						if (!ants.get(i).selectNextCity(pheromone)) {
							// ��������Ϣ����
							ants.get(i).setUseful(false);
							System.out.println("useful:" + ants.get(i).isUseful());
							System.out.println("====ant:" + i + " end====");
							break;
						}
					}
				}
				// �ֲ�������Ϣ��
				for (int j = 0; j < ants.get(i).getTabu().size() - 1; j++) {
					int city1 = ants.get(i).getTabu().get(j).intValue();
					int city2 = ants.get(i).getTabu().get(j + 1).intValue();
					float delta = (float) (1. / ants.get(i).getTourLength());
					SingleDelta singleDelta = new SingleDelta(city1, city2, delta);
					for (int k = 0; k < ants.get(i).getDelta().size(); k++) {
						if (ants.get(i).getDelta().get(k).equals(singleDelta)) {
							ants.get(i).getDelta().set(k, singleDelta);
						}
					}

				}
				// ��������ߵ��յ㣬����������·���ʸ�
				if (ants.get(i).isUseful()) {
					if (ants.get(i).getTourLength() < bestLength) {
						bestLength = ants.get(i).getTourLength();
						bestTour = ants.get(i).getTabu();
					}
				}
			}

			// ȫ�ָ�����Ϣ��
			updatePheromone();

			// ���³�ʼ������
			for (int i = 0; i < ants.size(); i++) {
				ants.get(i).init();
			}
		}

		// ��ӡ��ѽ��
		printOptimal(fileOutUrl);
	}

	/**
	 * ȫ�ָ�����Ϣ��,ֻ���ڱ߸���
	 */
	private void updatePheromone() {
		for (int i = 0; i < cityPath.size(); i++) {
			for (int j = 0; j < cityPath.get(i).size(); j++) {
				int end = cityPath.get(i).get(j);
				pheromone[i][end] = pheromone[i][end] * (1 - rho);
				for (int k = 0; k < ants.size(); k++) {
					pheromone[i][end] += ants.get(k).getSingleDelta(i, end);
				}
			}

		}
	}

	/**
	 * ��ӡ��ѽ��
	 */
	private void printOptimal(String fileOutUrl) {
		File fileOut = new File(fileOutUrl);
		BufferedWriter out = null;
		try {
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileOut)));
			if (bestLength == Integer.MAX_VALUE) {
				out.write("Unreachable");
				System.out.println("Unreachable");
			} else {
				out.write("The optimal tour is: " + bestTour + "\r\n");
				out.write("The optimal length is: " + bestLength);
				System.out.println("The optimal tour is: " + bestTour);
				System.out.println("The optimal length is: " + bestLength);
			}
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}