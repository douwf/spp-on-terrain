package aco;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Random;

public class RandomFile {
	/**
	 * ������������ļ�
	 * 
	 * @param n
	 *            һ��n*n����
	 */
	public void createPosFile(int n) {
		BufferedWriter out = null;
		File file = new File("F:\\pos.txt");
		try {
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
			Random ran = new Random();
			for (int i = 0; i < n * n; i++) {
				int x = ran.nextInt(150);
				int y = ran.nextInt(150);
				int z = ran.nextInt(150);
				out.write(x + " " + y + " " + z + "\r\n");
			}
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * ���������������ڵ��ϵ�ļ�
	 * 
	 * @param n
	 *            n*n����
	 */

	public void four_desp(int n) {
		File file = new File("F:\\fourNeighbor.txt");
		BufferedWriter out = null;

		try {
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
			for (int i = 0; i < n * n; i++) {
				if (i % n != n - 1) {
					out.write(i + " " + (i + 1) + "\r\n");
				}
				if (i / n != n - 1) {
					out.write(i + " " + (i + n) + "\r\n");
				}
			}
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new RandomFile().createPosFile(40);
		new RandomFile().four_desp(40);
	}

}
