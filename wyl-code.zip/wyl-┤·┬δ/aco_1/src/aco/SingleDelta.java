package aco;

public class SingleDelta {
	private int city1;
	private int city2;
	private float delta;//��Ϣ��

	public SingleDelta(int city1, int city2, float delta) {
		this.city1 = city1;
		this.city2 = city2;
		this.delta = delta;
	}

	public float getDelta() {
		return delta;
	}

	public void setDelta(float delta) {
		this.delta = delta;
	}

	@Override
	public boolean equals(Object obj) {
		SingleDelta other = (SingleDelta) obj;
		if (city1 == other.city1 && city2 == other.city2)
			return true;
		if (city1 == other.city2 && city2 == other.city1)
			return true;
		return false;
	}

}
